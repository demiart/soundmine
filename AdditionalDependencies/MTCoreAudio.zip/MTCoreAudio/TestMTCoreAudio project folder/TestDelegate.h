//
//  TestDelegate.h
//  TestMTCoreAudio
//
//  Created by Michael Thornburgh on Fri Dec 28 2001.
//  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface TestDelegate : NSObject {

}
/*

- (void) audioHardwareDeviceListDidChange;
- (void) audioHardwareDefaultInputDeviceDidChange;
- (void) audioHardwareDefaultOutputDeviceDidChange;
- (void) audioHardwareDefaultSystemOutputDeviceDidChange;

- (void) audioDeviceDidDie:(id)sender;
- (void) audioDeviceBufferSizeInFramesDidChange:(id)sender;
- (void) audioDeviceStreamsListDidChange:(id)sender;
- (void) audioDeviceChannelsByStreamDidChange:(id)sender forDirection:(MTCoreAudioDirection)theDirection;
- (void) audioDeviceStreamDescriptionDidChange:(id)sender forChannel:(UInt32)theChannel forDirection:(MTCoreAudioDirection)theDirection;
- (void) audioDeviceVolumeInfoDidChange:(id)sender forChannel:(UInt32)theChannel forDirection:(MTCoreAudioDirection)theDirection;
- (void) audioDeviceVolumeDidChange:(id)sender forChannel:(UInt32)theChannel forDirection:(MTCoreAudioDirection)theDirection;
- (void) audioDeviceMuteDidChange:(id)sender forChannel:(UInt32)theChannel forDirection:(MTCoreAudioDirection)theDirection;
- (void) audioDevicePlayThruDidChange:(id)sender forChannel:(UInt32)theChannel forDirection:(MTCoreAudioDirection)theDirection;
- (void) audioDeviceSourceDidChange:(id)sender forDirection:(MTCoreAudioDirection)theDirection;
- (void) audioDeviceClockSourceDidChange:(id)sender forChannel:(UInt32)theChannel forDirection:(MTCoreAudioDirection)theDirection;
- (void) audioStreamStreamDescriptionDidChange:(id)sender forSide:(MTCoreAudioStreamSide)theSide;
- (void) audioStreamVolumeInfoDidChange:(id)sender forChannel:(UInt32)theChannel;
- (void) audioStreamVolumeDidChange:(id)sender forChannel:(UInt32)theChannel;
- (void) audioStreamMuteDidChange:(id)sender forChannel:(UInt32)theChannel;
- (void) audioStreamPlayThruDidChange:(id)sender forChannel:(UInt32)theChannel;
- (void) audioStreamSourceDidChange:(id)sender;
- (void) audioStreamClockSourceDidChange:(id)sender forChannel:(UInt32)theChannel;

*/

@end
